export function gerarFechamentoPDF(data) {
  // Geração de PDF com jsPDF ou similar
  console.log("Gerar PDF para:", data)
}
