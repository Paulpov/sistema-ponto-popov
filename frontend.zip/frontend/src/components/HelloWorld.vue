<template>
  <div class="p-4">
    <h1 class="text-xl font-bold">Hello World Component</h1>
  </div>
</template>
