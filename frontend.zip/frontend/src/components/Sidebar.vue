<template>
  <aside class="w-full md:w-64 bg-gray-100 p-4">
    <nav>
      <ul class="space-y-2">
        <li><router-link to="/dashboard">Dashboard</router-link></li>
        <li><router-link to="/admin">Admin</router-link></li>
        <li><router-link to="/motorista">Motorista</router-link></li>
        <li><router-link to="/funcionario">Funcionário</router-link></li>
        <li><router-link to="/fechamento">Fechamento PJ</router-link></li>
      </ul>
    </nav>
  </aside>
</template>
