<!-- src/components/Footer.vue -->
<template>
    <footer class="text-center py-4 text-sm text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700">
      © 2025 Popov Transportes · Todos os direitos reservados
    </footer>
  </template>
  