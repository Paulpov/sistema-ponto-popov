<template>
  <div>
    <h2 class="text-2xl font-semibold">Painel do Motorista</h2>
    <p>Botões de status, monitoramento GPS e jornada.</p>
  </div>
</template>
