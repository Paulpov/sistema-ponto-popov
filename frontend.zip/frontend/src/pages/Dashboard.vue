<template>
  <div>
    <h2 class="text-2xl font-semibold">Dashboard</h2>
    <p>Resumo do ponto, rotas e produtividade.</p>
  </div>
</template>
