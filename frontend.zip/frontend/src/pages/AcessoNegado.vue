<template>
    <div class="p-6 text-center">
      <h1 class="text-2xl font-bold text-red-600">🚫 Acesso Negado</h1>
      <p class="mt-2 text-gray-700">Você não tem permissão para acessar esta página.</p>
    </div>
  </template>
  