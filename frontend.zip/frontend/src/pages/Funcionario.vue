<template>
  <div>
    <h2 class="text-2xl font-semibold">Painel do Funcionário</h2>
    <p>Registro de ponto, jornada compensatória e relatórios.</p>
  </div>
</template>
