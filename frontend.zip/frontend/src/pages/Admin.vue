<template>
  <div>
    <h2 class="text-2xl font-semibold">Painel do Administrador</h2>
    <p>Controle de usuários, ajustes e relatórios.</p>
  </div>
</template>
