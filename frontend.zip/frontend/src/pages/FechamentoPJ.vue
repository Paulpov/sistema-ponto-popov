<template>
  <div>
    <h2 class="text-2xl font-semibold mb-4">Fechamento de Prestador PJ</h2>
    <p>Fechamento com e sem comissão, geração de PDF e histórico mensal.</p>
  </div>
</template>
